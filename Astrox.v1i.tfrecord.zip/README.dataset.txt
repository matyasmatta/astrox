# Astrox > 2023-01-20 3:28pm
https://universe.roboflow.com/masarykovo-gymnzium/astrox

Provided by a Roboflow user
License: CC BY 4.0

